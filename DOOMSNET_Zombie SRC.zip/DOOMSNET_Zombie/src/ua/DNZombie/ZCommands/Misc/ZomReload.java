package ua.DNZombie.ZCommands.Misc;

import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.User;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class ZomReload extends ListenerAdapter
{
	@Override
    public void onMessageReceived(final MessageReceivedEvent event) {
        final Message msg = event.getMessage();
        final MessageChannel channel = event.getChannel();
        final User user = event.getAuthor();
        if (msg.getContentRaw().equals("*rzombie")) {
        	if(msg.getChannel() != null) {
        		if (user.getId().contains("551133003015913499") || user.getId().contains("769994392567021569")){
        			channel.sendMessage("Restarting...").queue();
                    System.exit(0);
        		} else {
        			event.getChannel().sendMessage("No permission to reload!").queue();
        		}
        	}
        }
    }
}
