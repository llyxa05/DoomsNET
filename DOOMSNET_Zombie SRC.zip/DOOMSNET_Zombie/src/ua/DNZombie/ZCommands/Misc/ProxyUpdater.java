package ua.DNZombie.ZCommands.Misc;

import java.awt.Color;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class ProxyUpdater extends ListenerAdapter
{
    @Override
    public void onMessageReceived(final MessageReceivedEvent event) {
    	final MessageChannel channel = event.getChannel();
        final EmbedBuilder eb = new EmbedBuilder();
    	final Message msg = event.getMessage();
    	if (msg.getContentRaw().equals("*upd")) {
    		if(msg.getChannel() != null) {
                eb.addField("☠ Zombie answer ☠", "Sucessfully updated proxies.txt!", true);
                eb.setColor(Color.BLACK);
                channel.sendMessageEmbeds(eb.build(), new MessageEmbed[0]).queue();
                GetProxy.getProxy();
    		}
    	} 
    }
}
