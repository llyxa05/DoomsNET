package ua.DNZombie.ZCommands.Misc;

import java.io.FileOutputStream;
import java.net.URL;
import java.nio.channels.Channels;
import java.nio.channels.ReadableByteChannel;
import java.util.Date;

public class GetProxy {
    public static void getProxy() {
        try {
            Date date = new Date();
            String path = "proxies.txt";
            final URL website = new URL("http://api.openproxylist.xyz/socks4.txt");
            final ReadableByteChannel rbc = Channels.newChannel(website.openStream());
            final FileOutputStream fos = new FileOutputStream(path);
            fos.getChannel().transferFrom(rbc, 0L, Long.MAX_VALUE);
            fos.close();
            rbc.close();
            System.out.println(date.toString() + "[*] Sucsessfuly scraped proxies from database.");
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }
}