package ua.DNZombie.ZCommands.Misc;

import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class RSZombieCommand extends ListenerAdapter
{
	@Override
    public void onMessageReceived(final MessageReceivedEvent event) {
        final Message msg = event.getMessage();
        final MessageChannel channel = event.getChannel();
        final long time = System.currentTimeMillis();
        if (msg.getContentRaw().equals("*rs")) {
        	if(msg.getChannel() != null) {
                channel.sendMessage("Checking...").queue(response -> response.editMessageFormat("Response of zombie: %d ms", System.currentTimeMillis() - time).queue());
        	}
        }
    }
}
