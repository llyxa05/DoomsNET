package ua.DNZombie.ZCommands.Misc;

import java.awt.Color;

import net.dv8tion.jda.api.EmbedBuilder;
import net.dv8tion.jda.api.entities.Message;
import net.dv8tion.jda.api.entities.MessageChannel;
import net.dv8tion.jda.api.entities.MessageEmbed;
import net.dv8tion.jda.api.events.message.MessageReceivedEvent;
import net.dv8tion.jda.api.hooks.ListenerAdapter;

public class ZStatistic extends ListenerAdapter
{
    float mb;
    Runtime runtime;
    
    public ZStatistic() {
        this.mb = 1048576.0f;
        this.runtime = Runtime.getRuntime();
    }
    
    @Override
    public void onMessageReceived(final MessageReceivedEvent event) {
        final Message msg = event.getMessage();
        final MessageChannel channel = event.getChannel();
        final EmbedBuilder eb = new EmbedBuilder();
        if (msg.getContentRaw().equals("*stat")) {
        	if(msg.getChannel() != null) {
                eb.setTitle("☠ Load Statictic ☠");
                eb.addField("Used Memory", String.valueOf((this.runtime.totalMemory() - this.runtime.freeMemory()) / this.mb) + " MB", true);
                eb.addField("Free Memory", String.valueOf(this.runtime.freeMemory() / this.mb) + " MB", false);
                eb.addField("Max Memory", String.valueOf(this.runtime.maxMemory() / this.mb) + " MB", false);
                eb.setColor(Color.GREEN);
                channel.sendMessageEmbeds(eb.build(), new MessageEmbed[0]).queue();
        	}
        }
    }
}