package ua.DNZombie;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import net.dv8tion.jda.api.JDA;
import net.dv8tion.jda.api.JDABuilder;
import net.dv8tion.jda.api.OnlineStatus;
import net.dv8tion.jda.api.entities.Activity;
import ua.DNZombie.Utils.Rainbow;
import ua.DNZombie.ZCommands.Main.*;
import ua.DNZombie.ZCommands.Misc.*;
import ua.DNZombie.ZCommands.Test.*;


public class Main {
	
	public static String Token;

	public static void main(final String[] args) throws Exception {
		try {
			final File token = new File("token.txt");
            final BufferedReader bufferedReader = new BufferedReader(new FileReader(token));
            String strings = "";
            while ((strings = bufferedReader.readLine()) != null) {
                Main.Token = strings;
            }
            System.out.println("Token installed!");
		}catch(IOException e){
			System.out.println("Token not found!");
		}
		final JDA jda = JDABuilder.createDefault(Token)
				.setActivity(Activity.playing("Bounce 2000 | Bots in active!"))
				.setStatus(OnlineStatus.IDLE)
				.build();
		
		
		jda.addEventListener(new ProxyUpdater());
		System.out.println(Rainbow.green("Loaded ProxyUpdater"));
		jda.addEventListener(new RSZombieCommand());
		System.out.println(Rainbow.green("Loaded RSZombieCommand"));
		//jda.addEventListener(new BasicHttpFlood());
		//System.out.println(Rainbow.green("Loaded BasicHttpFlood"));
		jda.addEventListener(new BadpLaunch());
		System.out.println(Rainbow.green("Loaded BadpLaunch"));
		jda.addEventListener(new BjoinLaunch());
		System.out.println(Rainbow.green("Loaded BjoinLaunch"));
		jda.addEventListener(new ZStatistic());
		System.out.println(Rainbow.green("Loaded ZStatistic"));
		jda.addEventListener(new HttpRipLaunch());
		System.out.println(Rainbow.green("Loaded HttpRipLaunch"));
		jda.addEventListener(new ZomReload());
		System.out.println(Rainbow.green("Loaded ZombieReload"));
		
		System.out.println("[16:00:46 INFO]: Done (23.653s)! For help, type \"help\" or \"?\"");
		System.out.println(Rainbow.green("Zombie online!"));
	}
}
